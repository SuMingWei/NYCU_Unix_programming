set -e
cd ./kshram
make install
cd ..
cd ./rootfs
find . -print | cpio -ov -H newc -F ../rootfs.cpio
cd ..
bzip2 -z ./rootfs.cpio 
mv ./rootfs.cpio.bz2 ./dist