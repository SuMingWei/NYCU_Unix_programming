typedef void (*sort_funcptr_t)(long *numbers, int n);
void quicksort(long *numbers, int left, int right){
    int i = left, j = right;
    long pivot = numbers[(left + right) / 2];
    long temp;

    while (i <= j) {
        while (numbers[i] < pivot)
            i++;
        while (numbers[j] > pivot)
            j--;
        if (i <= j) {
            temp = numbers[i];
            numbers[i] = numbers[j];
            numbers[j] = temp;
            i++;
            j--;
        }
    }

    if (left < j)
        quicksort(numbers, left, j);
    if (i < right)
        quicksort(numbers, i, right);
}

sort_funcptr_t sorting(long *numbers, int n) {
    if (n > 1) {
        long pivot = numbers[n/2];
        long *left = &numbers[0];
        long *right = &numbers[n-1];
        long tmp;

        while (left <= right) {
            while (*left < pivot){
                left++;
            } 
            while (*right > pivot){
                right--;
            } 
            if(left <= right){
                tmp = *left;
                *left = *right;
                *right = tmp;

                left++;
                right--;
            }
        }
        // left recursive
        sorting(numbers, right-numbers+1);
        // right recursive
        sorting(left, numbers+n-left);
    }
}




