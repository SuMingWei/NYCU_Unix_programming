#include <stdio.h>
#include <stdlib.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/user.h>

void errquit(const char *msg) {
	perror(msg);
	exit(-1);
}

void intToString(char *str, int num){
	// Convert the number to a 10-bit binary string
    for (int i = 0; i < 9; i++) {
        str[i] = (num & (1 << (8 - i))) ? '1' : '0';
    }
    str[9] = '\0';

	return;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <program>\n", argv[0]);
        return 1;
    }

    pid_t child_pid;

    if((child_pid = fork()) < 0) errquit("fork");

    if(child_pid == 0) {
		// if(ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) errquit("ptrace@child");
		// execvp(argv[1], argv+1);
		// errquit("execvp");

        // Child process
        ptrace(PTRACE_TRACEME, 0, NULL, NULL);
        execl(argv[1], argv[1], NULL);
	} else {
		long long counter = 0LL;
		int wait_status;
		struct user_regs_struct regs;
		unsigned long long rip, rax, snapshot, magic_address;

		char magic[16] = {0};
		int trials = 0;

		// printf("%s\n", magic);


		if(waitpid(child_pid, &wait_status, 0) < 0) errquit("waitpid");
        printf("Tracing started...\n");

		ptrace(PTRACE_SETOPTIONS, child_pid, 0, PTRACE_O_EXITKILL);
		while (WIFSTOPPED(wait_status)) {
			counter++;

			// rdi
			// rip
			// printf("counter = %lld\n", counter);
			// if(ptrace(PTRACE_GETREGS, child_pid, 0 ,&regs) == 0){
			// 	rip = regs.rip;
			// 	printf("rip: %p\n", rip);
			// }

			if(counter == 3){
				// get magic address
				if(ptrace(PTRACE_GETREGS, child_pid, 0 ,&regs) == 0){
					rax = regs.rax;
					magic_address = rax;
					printf("rax: %p\n", rax);
				}
			}
			if(counter == 4){
				if(ptrace(PTRACE_GETREGS, child_pid, 0 ,&regs) == 0){
					rip = regs.rip;
					snapshot = rip;
					printf("rip: %p\n", rip);
				}
			}
			if(counter == 6){
				// get the return value of oracle_get_flag()
				if(ptrace(PTRACE_GETREGS, child_pid, 0 ,&regs) == 0){
					rax = regs.rax;
					// printf("rax: %p\n", rax);
				}

				// check whether get the bingo
				if(rax == 0xffffffff){
					// set rip to snapshot
					regs.rip = snapshot;
					ptrace(PTRACE_SETREGS, child_pid, 0 ,&regs);
					counter -= 2;

					// update magic
					intToString(magic, ++trials);
					// printf("magic: %s\n", magic);
					// ptrace(PTRACE_POKEDATA, child_pid, magic_address, (void *)magic);
					ptrace(PTRACE_POKETEXT, child_pid, magic_address, *(unsigned long *)magic);
					ptrace(PTRACE_POKETEXT, child_pid, magic_address+0x8, *(unsigned long *)(&magic[8]));
					// if(trials == 10) exit(0);
				}
			}

			if(ptrace(PTRACE_CONT, child_pid, 0, 0) < 0) errquit("ptrace@parent");
			if(waitpid(child_pid, &wait_status, 0) < 0){
                errquit("waitpid");
            }
		}
		// fprintf(stderr, "## %lld instruction(s) executed\n", counter);
	}
    
    return 0;
}
